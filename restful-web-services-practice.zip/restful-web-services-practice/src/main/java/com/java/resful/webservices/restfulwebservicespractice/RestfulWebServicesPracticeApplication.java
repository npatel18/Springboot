package com.java.resful.webservices.restfulwebservicespractice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestfulWebServicesPracticeApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestfulWebServicesPracticeApplication.class, args);
	}

}

